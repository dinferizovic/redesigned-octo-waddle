var session = TB.initSession(sessionId);

var options = {width: 150, height: 150, insertMode: 'append'}
var publisher = TB.initPublisher(apiKey, 'publisher', options);

session.on({

  sessionConnected: function(event) {
    session.publish(publisher);
    resize_stream(publisher.element.id)
  },

  
  streamCreated: function(event) {

    var subContainer = document.createElement('div');
    subContainer.id = 'stream-' + event.stream.streamId;
    document.getElementById('subscribers').appendChild(subContainer);
    session.subscribe(event.stream, subContainer, options);
    resize_stream(subContainer.id);

  }

});

session.connect(apiKey, token);