$(document).ready(function() {

	$( "#do_try_pls" ).click(function() {
		  
	console.log("click");
			$.ajax({
				data : {
					name : "$('#nameInput').val()",
					email : "$('#emailInput').val()"
				},
				type : 'POST',
				url : '/process'
			})
			.done(function(data) {

				if (data.error) {
					alert("Actually error")
				}
				else {
					alert(data.name)
				}

			});
			event.preventDefault();

		});





	});