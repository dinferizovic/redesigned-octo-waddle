var is_fs = false;
                function makeButton(src) {
                    var btnImg = document.createElement('img');
                    btnImg.setAttribute('src', src);
                    btnImg.setAttribute('width', '24px');
                    btnImg.setAttribute('height', '24px');
                    return btnImg;
                  }


                var aww = new AwwBoard('#aww-wrapper', {
                    /* make sure you're using your own key here */
                    apiKey: 'd9d84011-f07b-4c58-9e81-3f6c8a9b9d2f',
                    /* put a unique text here */
                    boardLink: 'zecpita',
                    menuItems: {
                         chatIt: {
                          style: {background: 'lightgray'},
                          onclick: function() { console.log(aww.toggleChatWindow());},
                          content: makeButton('http://www.entypo.com/images/chat.svg')
                        },
                        toggleFullScreen: {
                          style: {background: 'lightgray'},
                          onclick: function() { 
                            if (!is_fs) {
                            document.getElementById("footer").style.display = "none";
                            document.getElementById("aww-wrapper").style.height = "80vh";
                            aww.doRedraw()
                            is_fs = true;}
                            else {
                                document.getElementById("footer").style.display = "block";
                                document.getElementById("aww-wrapper").style.height = "60vh";
                                is_fs = false;
                                aww.doRedraw()

                            } 
                          },
                          content: makeButton('http://www.entypo.com/images/resize-full-screen.svg')
                        },

                  },
                  menuOrder:[ 'chatIt', 'toggleFullScreen'],
                  defaultTool: 'mark'


                });