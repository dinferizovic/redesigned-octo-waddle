from flask import Flask, render_template, jsonify, request, g, redirect, url_for
from opentok import OpenTok
from flask_bootstrap import Bootstrap
from base64 import b16encode as b16e
from base64 import b16decode as b16d


speech_says_w = ""

room_limit = 1
rooms = []
api_key = "45762552"
api_secret = "968d53d1d0b9210d5ad4f26269e01f86356f4e92"
app = Flask(__name__)

bootstrap = Bootstrap(app)
opentok = OpenTok(api_key, api_secret)



@app.route("/room/<roomid>/<user>")
def hello(roomid, user):
	key = api_key

	session_id =  None
	token = None
	
	global rooms
	exists = False
	varadmin = ""
	for room in rooms:
		if room["room_name"] ==roomid:
			exists = True
			session_id = room["session_r"].session_id
			token = opentok.generate_token(session_id)


	return render_template('index.html', api_key=key, session_id=session_id, token=token, is_available = exists, user=user, roomid=roomid)

@app.route("/", methods=['GET', 'POST'])
def front():
	lectname = None
	if request.method == 'POST' and 'lectname' in request.form:
		lectname = request.form['lectname']

		global rooms
		room_example2 = {
			"room_name": request.form['lectname'],
			"lectname" : request.form['name'],
			"type" : request.form['option'],
			"session_r" : opentok.create_session()
			}
		rooms.append(room_example2)


		return redirect( url_for("hello", roomid= lectname, user="admin")  )
	return render_template('front.html', lectname=lectname, whatinform=request.form)

@app.route("/current")
def current_p():
	global rooms
	return render_template('current.html', var=rooms)

@app.route("/archive")
def archive_p():
    return render_template('archive.html')


@app.route('/process', methods=['POST', 'GET'])
def process():
	try:
		global speech_says_w
		if request.method == 'POST':
			speech_says_w = request.form["text"]
			return jsonify( { "text" : speech_says_w } )
		else:
			return speech_says_w
	except Exception as e:
		return str(e)


@app.route('/join', methods=['POST', 'GET'])
def join_r():
	if request.method == 'POST':
		return redirect( url_for("hello", roomid= request.form["fname"], user="user")  )
	return render_template('join_room.html')

@app.route("/removeroom/<roomname>")
def remroom(roomname):
    global rooms
    for i in range(0, len(rooms)):
    	if rooms[i]["room_name"] == roomname:
    		del rooms[i]
    		break 

    return redirect(url_for("front") )

if __name__ == "__main__":
    context = ('crt.cert', 'key.key')
    app.run(host='0.0.0.0', port=8001, ssl_context=context, debug=True)
